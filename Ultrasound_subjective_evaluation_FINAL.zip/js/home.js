const reviewerSelect = document.getElementById("reviewer");
const taskList = document.getElementById("taskList");

CONFIG.REVIEWERS.forEach(reviewer => {
  const option = document.createElement("option");
  option.value = reviewer;
  option.textContent = reviewer;
  reviewerSelect.appendChild(option);
});

reviewerSelect.addEventListener("change", loadManifest);

async function gasPost(payload) {
  const res = await fetch(CONFIG.GAS_URL, {
    method: "POST",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify(payload)
  });
  return await res.json();
}

async function loadManifest() {
  const res = await fetch("manifest.json?ts=" + Date.now());
  const tasks = await res.json();

  const reviewer = reviewerSelect.value;
  let progress = {};

  if (reviewer) {
    try {
      const result = await gasPost({ action: "loadAllProgress", reviewer });
      if (result.ok) progress = result.progress || {};
    } catch (e) {
      console.warn(e);
    }
  }

  renderTasks(tasks, progress);
}

function renderTasks(tasks, progress) {
  taskList.innerHTML = "";

  const grouped = {};
  tasks.forEach(task => {
    if (!grouped[task.strategy]) grouped[task.strategy] = {};
    if (!grouped[task.strategy][task.dataset]) grouped[task.strategy][task.dataset] = [];
    grouped[task.strategy][task.dataset].push(task);
  });

  Object.keys(grouped).forEach(strategy => {
    const section = document.createElement("div");
    section.className = "task-section";

    const title = document.createElement("h3");
    title.textContent = strategy;
    section.appendChild(title);

    Object.keys(grouped[strategy]).forEach(dataset => {
      const datasetTitle = document.createElement("h4");
      datasetTitle.textContent = dataset;
      section.appendChild(datasetTitle);

      grouped[strategy][dataset].forEach(task => {
        const modelDisplay = CONFIG.MODEL_MAP[task.model] || task.model;
        const pkey = [task.strategy, task.dataset, task.model].join("|");
        const p = progress[pkey] || {};
        const total = task.images ? task.images.length * CONFIG.METRICS.length * CONFIG.IMAGE_POSITIONS.length : 0;
        const answered = Number(p.answered_count || 0);
        const status = p.status || (answered > 0 ? "In Progress" : "Not Started");

        const card = document.createElement("div");
        card.className = "task-card";

        card.innerHTML = `
          <div class="task-title">${modelDisplay}</div>
          <div class="task-meta">${task.strategy} / ${task.dataset}</div>
          <div class="task-meta">Progress: ${answered} / ${total} (${status})</div>
          <button onclick="startSurvey('${task.strategy}', '${task.dataset}', '${task.model}')">
            開始 / 繼續評分
          </button>
          <button onclick="viewHistory('${task.strategy}', '${task.dataset}', '${task.model}')">
            查看作答紀錄
          </button>
        `;

        section.appendChild(card);
      });
    });

    taskList.appendChild(section);
  });
}

function getReviewerOrAlert() {
  const reviewer = reviewerSelect.value;
  if (!reviewer) {
    alert("請先選擇 Reviewer");
    return null;
  }
  return reviewer;
}

function startSurvey(strategy, dataset, model) {
  const reviewer = getReviewerOrAlert();
  if (!reviewer) return;

  window.location.href =
    `survey.html?reviewer=${encodeURIComponent(reviewer)}&strategy=${encodeURIComponent(strategy)}&dataset=${encodeURIComponent(dataset)}&model=${encodeURIComponent(model)}`;
}

function viewHistory(strategy, dataset, model) {
  const reviewer = getReviewerOrAlert();
  if (!reviewer) return;

  window.location.href =
    `history.html?reviewer=${encodeURIComponent(reviewer)}&strategy=${encodeURIComponent(strategy)}&dataset=${encodeURIComponent(dataset)}&model=${encodeURIComponent(model)}`;
}

loadManifest();
