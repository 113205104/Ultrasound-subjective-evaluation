const CONFIG = {
  GAS_URL:
    "https://script.google.com/macros/s/AKfycbx0pXw3alThi70IDIO30FbH_2Tg1SvuzfVsJMpQYOUk4k1fr2nUmwLlPOElc4eU7WU/exec",

  REVIEWERS: ["Reviewer1", "Reviewer2"],

  MODEL_MAP: {
    cut: "Model A",
    cyc: "Model B",
    fast: "Model C",
    p2p: "Model D",
    reg: "Model E"
  },

  METRICS: [
    "Whole image quality",
    "Noise suppression",
    "Contrast",
    "Edge sharpness"
  ],

  IMAGE_POSITIONS: ["第一張", "第二張", "第三張"],
  SCORES: [1, 2, 3, 4],
  GROUPS_PER_PAGE: 5
};
