const params = new URLSearchParams(window.location.search);

const reviewer = params.get("reviewer");
const strategy = params.get("strategy");
const dataset = params.get("dataset");
const model = params.get("model");
const modelDisplay = CONFIG.MODEL_MAP[model] || model;

let manifestData = [];
let task = null;
let page = 0;
let responses = {};

document.getElementById("taskTitle").textContent = modelDisplay;
document.getElementById("taskInfo").textContent =
  `${reviewer} / ${strategy} / ${dataset}`;
const syncStatus = document.getElementById("syncStatus");

function goHome() {
  window.location.href = "index.html";
}

async function gasPost(payload) {
  const res = await fetch(CONFIG.GAS_URL, {
    method: "POST",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify(payload)
  });
  return await res.json();
}

async function loadTask() {
  const res = await fetch("manifest.json?ts=" + Date.now());
  manifestData = await res.json();

  task = manifestData.find(t =>
    t.strategy === strategy &&
    t.dataset === dataset &&
    t.model === model
  );

  if (!task) {
    document.getElementById("surveyArea").innerHTML =
      "<p>找不到此任務，請回首頁。</p>";
    return;
  }

  try {
    const result = await gasPost({
      action: "loadTask",
      reviewer,
      strategy,
      dataset,
      model
    });

    if (result.ok) {
      responses = result.responses || {};
      page = Number(result.page_index || 0);
    }
  } catch (e) {
    console.warn(e);
    syncStatus.textContent = "雲端讀取失敗，仍可作答，但請確認網路。";
  }

  renderPage();
}

function imagePath(img) {
  if (img.image_url) return img.image_url;
  return `images/${strategy}/${dataset}/${model}/${img.file}`;
}

function responseKey(group, metric, position) {
  return `${group}|${metric}|${position}`;
}

function totalItems() {
  return task.images.length * CONFIG.METRICS.length * CONFIG.IMAGE_POSITIONS.length;
}

function renderPage() {
  const start = page * CONFIG.GROUPS_PER_PAGE;
  const end = Math.min(start + CONFIG.GROUPS_PER_PAGE, task.images.length);
  const images = task.images.slice(start, end);

  const area = document.getElementById("surveyArea");
  area.innerHTML = "";

  images.forEach(img => {
    const groupText = String(img.group).padStart(3, "0");

    const card = document.createElement("div");
    card.className = "task-card";

    card.innerHTML = `
      <div class="task-title">${modelDisplay} 組別${groupText}</div>
      <div class="task-meta">${img.file || ""}</div>
      <img class="tripanel" src="${imagePath(img)}" alt="${groupText}">
    `;

    CONFIG.METRICS.forEach(metric => {
      const block = document.createElement("div");
      block.className = "metric-block";

      const title = document.createElement("div");
      title.className = "metric-title";
      title.textContent = `${groupText}. ${metric}`;
      block.appendChild(title);

      const table = document.createElement("table");
      table.className = "rating-table";

      let html = "<tr><th>影像</th>";
      CONFIG.SCORES.forEach(s => html += `<th>${s}</th>`);
      html += "</tr>";

      CONFIG.IMAGE_POSITIONS.forEach(pos => {
        html += `<tr><td>${pos}</td>`;
        CONFIG.SCORES.forEach(score => {
          const key = responseKey(groupText, metric, pos);
          const checked = responses[key] == score ? "checked" : "";
          html += `
            <td>
              <input type="radio"
                     name="${key}"
                     value="${score}"
                     ${checked}
                     onchange="saveScore('${groupText}', '${metric}', '${pos}', '${score}', '${img.machine_group || ""}', '${img.organ || ""}', '${img.file || ""}')">
            </td>
          `;
        });
        html += "</tr>";
      });

      table.innerHTML = html;
      block.appendChild(table);
      card.appendChild(block);
    });

    area.appendChild(card);
  });

  document.getElementById("pageInfo").textContent =
    `第 ${page + 1} / ${Math.ceil(task.images.length / CONFIG.GROUPS_PER_PAGE)} 頁`;

  document.getElementById("prevBtn").disabled = page === 0;
  document.getElementById("nextBtn").disabled =
    page >= Math.ceil(task.images.length / CONFIG.GROUPS_PER_PAGE) - 1;
}

async function saveScore(group, metric, position, score, machineGroup, organ, filename) {
  const key = responseKey(group, metric, position);
  responses[key] = score;
  localStorage.setItem("survey_backup", JSON.stringify(responses));
  syncStatus.textContent = "正在儲存...";

  try {
    const result = await gasPost({
      action: "saveScore",
      reviewer,
      strategy,
      dataset,
      model,
      model_display: modelDisplay,
      group,
      machine_group: machineGroup,
      organ,
      filename,
      metric,
      image_position: position,
      score,
      total_items: totalItems(),
      page_index: page
    });

    if (!result.ok) throw new Error(result.error || "save failed");
    syncStatus.textContent = "已儲存：" + new Date().toLocaleTimeString();
  } catch (e) {
    console.error(e);
    syncStatus.textContent = "雲端儲存失敗，已暫存在此瀏覽器。";
  }
}

document.getElementById("prevBtn").onclick = () => {
  if (page > 0) {
    page--;
    renderPage();
    window.scrollTo(0, 0);
  }
};

document.getElementById("nextBtn").onclick = () => {
  if (page < Math.ceil(task.images.length / CONFIG.GROUPS_PER_PAGE) - 1) {
    page++;
    renderPage();
    window.scrollTo(0, 0);
  }
};

loadTask();
